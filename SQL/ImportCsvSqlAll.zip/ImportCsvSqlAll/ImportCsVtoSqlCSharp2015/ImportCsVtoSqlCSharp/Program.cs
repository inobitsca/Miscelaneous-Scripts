﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ImportCSVtoSQL
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Diagnostics.Stopwatch elapsed = new System.Diagnostics.Stopwatch();
            elapsed.Start(); Int64 rows = 0;
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy("server=sqlserver;database=locations;trusted_connection=yes",
                System.Data.SqlClient.SqlBulkCopyOptions.TableLock)
            {
                DestinationTableName = "AllCountries",
                BulkCopyTimeout = 0,
                BatchSize = 100000
            })
            {

                using (System.IO.StreamReader reader = new System.IO.StreamReader("C:\\temp\\allcountries.txt"))
                {
                    using (DataTable datatable = new DataTable())
                    {

                        var columns = datatable.Columns;
                        columns.Add("GeoNameID", typeof(System.Int32));
                        columns.Add("Name", typeof(System.String));
                        columns.Add("AsciiName", typeof(System.String));
                        columns.Add("AlternateNames", typeof(System.String));
                        columns.Add("Latitude", typeof(System.Decimal));
                        columns.Add("Longitude", typeof(System.Decimal));
                        columns.Add("FeatureClass", typeof(System.String));
                        columns.Add("FeatureCode", typeof(System.String));
                        columns.Add("CountryCode", typeof(System.String));
                        columns.Add("Cc2", typeof(System.String));
                        columns.Add("Admin1Code", typeof(System.String));
                        columns.Add("Admin2Code", typeof(System.String));
                        columns.Add("Admin3Code", typeof(System.String));
                        columns.Add("Admin4Code", typeof(System.String));
                        columns.Add("Population", typeof(System.Int64));
                        columns.Add("Elevation", typeof(System.String));
                        columns.Add("Dem", typeof(System.Int32));
                        columns.Add("Timezone", typeof(System.String));
                        columns.Add("ModificationDate", typeof(System.DateTime));
                        int batchsize = 0;

                        while (!reader.EndOfStream)
                        {

                            string[] line = reader.ReadLine().Split('\t');
                            datatable.Rows.Add(line);
                            batchsize += 1;
                            if (batchsize == 100000)
                            {
                                bulkcopy.WriteToServer(datatable);
                                datatable.Rows.Clear();
                                batchsize = 0;
                                Console.WriteLine("Flushing 100,000 rows");
                            }
                            rows += 1;
                        }
                        bulkcopy.WriteToServer(datatable);
                        datatable.Rows.Clear();
                    }
                }
            }
            elapsed.Stop();
            Console.WriteLine((rows + " records imported in " + elapsed.Elapsed.TotalSeconds + " seconds."));
            Console.ReadLine();
        }
    }
}