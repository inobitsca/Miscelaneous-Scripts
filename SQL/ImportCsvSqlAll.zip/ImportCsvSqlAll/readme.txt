In order to get this script to import over 91,000 rows/second, I did the following:

1. SQL Server and workstation were both on SSD drives
2. The SQL table contained no indexes (the primary key was removed)
3. TableLock was used
4. The database's recovery model was set to SIMPLE
5. The database disk space was preallocated

Running this script on the SQL Server itself (which I don't recommend in production environments), imported over 93,000 rows/sec.

If you'd like a formalized PowerShell module of this technique please visit: http://bit.ly/ImportCsvSql

- Chrissy LeMaire @cl, netnerds.net


