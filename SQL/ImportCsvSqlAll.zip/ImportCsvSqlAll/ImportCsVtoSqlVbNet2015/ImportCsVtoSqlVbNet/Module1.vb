﻿Module Module1
    Sub Main()

        Dim oTimer As New System.Diagnostics.Stopwatch
        oTimer.Start()
        Dim iRows As Int64 = 0

        Using oBulk As New Data.SqlClient.SqlBulkCopy("server=sqlserver;database=locations;trusted_connection=yes", SqlClient.SqlBulkCopyOptions.TableLock) With
        {.DestinationTableName = "AllCountries", .BulkCopyTimeout = 0, .BatchSize = 100000}

            Using oSR As New IO.StreamReader("C:\temp\allcountries.txt")
                Using oDT As New DataTable

                    With oDT.Columns
                        .Add("GeoNameID", GetType(System.Int32))
                        .Add("Name", GetType(System.String))
                        .Add("AsciiName", GetType(System.String))
                        .Add("AlternateNames", GetType(System.String))
                        .Add("Latitude", GetType(System.Decimal))
                        .Add("Longitude", GetType(System.Decimal))
                        .Add("FeatureClass", GetType(System.String))
                        .Add("FeatureCode", GetType(System.String))
                        .Add("CountryCode", GetType(System.String))
                        .Add("Cc2", GetType(System.String))
                        .Add("Admin1Code", GetType(System.String))
                        .Add("Admin2Code", GetType(System.String))
                        .Add("Admin3Code", GetType(System.String))
                        .Add("Admin4Code", GetType(System.String))
                        .Add("Population", GetType(System.Int64))
                        .Add("Elevation", GetType(System.String))
                        .Add("Dem", GetType(System.Int32))
                        .Add("Timezone", GetType(System.String))
                        .Add("ModificationDate", GetType(System.DateTime))
                    End With
                    Dim iBatchsize As Integer = 0

                    Do While Not oSR.EndOfStream
                        Dim sLine As String() = oSR.ReadLine.Split(vbTab)
                        oDT.Rows.Add(sLine)
                        iBatchsize += 1
                        If iBatchsize = 100000 Then
                            oBulk.WriteToServer(oDT)
                            oDT.Rows.Clear()
                            iBatchsize = 0
                            Console.WriteLine("Flushing 100,000 rows")
                        End If
                        iRows += 1
                    Loop
                    oBulk.WriteToServer(oDT)
                    oDT.Rows.Clear()
                End Using
            End Using
        End Using
        oTimer.Stop()
        Console.WriteLine(iRows.ToString & "Records imported in " & oTimer.Elapsed.TotalSeconds & " seconds.")
        Console.ReadLine()

    End Sub

End Module
