$oldSuffix = 'mccarthyltd.local'
 $newSuffix = 'mcmotor.com'
 Get-ADUser -SearchBase "OU=McCarthy Motor Holdings,DC=mccarthyltd,DC=local" -SearchScope OneLevel -filter * | ForEach-Object
 $newUpn = $_.UserPrincipalName.Replace($oldSuffix,$newSuffix)
 $_ | Set-ADUser -server yourDomainController -UserPrincipalName $newUpn -whatif
 }



