
Imports Microsoft.MetadirectoryServices
Imports System.Configuration
Imports System.Configuration.ConfigurationManager

Public Class MAExtensionObject
    Implements IMASynchronization

    Dim PermanentPrefix As String = ConfigurationManager.AppSettings("permanentPrefix").ToString


    Public Sub Initialize() Implements IMASynchronization.Initialize
        ' TODO: Add initialization code here
    End Sub

    Public Sub Terminate() Implements IMASynchronization.Terminate
        ' TODO: Add termination code here
    End Sub

    Public Function ShouldProjectToMV(ByVal csentry As CSEntry, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ShouldProjectToMV
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function

    Public Function FilterForDisconnection(ByVal csentry As CSEntry) As Boolean Implements IMASynchronization.FilterForDisconnection
        ' TODO: Add connector filter code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForJoin(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByRef values As ValueCollection) Implements IMASynchronization.MapAttributesForJoin
        ' TODO: Add join mapping code here
        Throw New EntryPointNotImplementedException()
    End Sub

    Public Function ResolveJoinSearch(ByVal joinCriteriaName As String, ByVal csentry As CSEntry, ByVal rgmventry() As MVEntry, ByRef imventry As Integer, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ResolveJoinSearch
        ' TODO: Add join resolution code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForImport(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByVal mventry As MVEntry) Implements IMASynchronization.MapAttributesForImport
        ' TODO: write your import attribute flow code
        Select Case FlowRuleName

            Case "IAFdisplayName" ' Build the display name based on the available display name fields
                ' Setting up the Initials
                Dim Initials As String = Nothing
                ' *** Implement once the secondName column has been added to SQL ***
                If csentry("Firstname").IsPresent And csentry("SecondName").IsPresent Then
                    Initials = csentry("Firstname").StringValue.Substring(0, 1) + csentry("SecondName").StringValue.Substring(0, 1)
                ElseIf csentry("Firstname").IsPresent Then
                    Initials = csentry("Firstname").StringValue.Substring(0, 1)
                ElseIf csentry("PreferredName").IsPresent Then
                    Initials = csentry("PreferredName").StringValue.Substring(0, 1)
                End If

                'If the test condition is met change the Displayname to be PreferredName Surname (Initial/s) 
                'Else Leave the Display name in the current format of Surname, PreferredName (Initial/s)
                If mventry("testCondition").IsPresent Then
                    If mventry("testCondition").Value = "TestAccount" And csentry("PreferredName").IsPresent And csentry("Surname").IsPresent Then
                        mventry("displayName").Value = csentry("PreferredName").Value + " " + csentry("Surname").Value + " (" + Initials + ")"
                    Else
                        mventry("displayName").Value = csentry("Firstname").Value + " " + csentry("Surname").Value + " (" + Initials + ")"
                    End If
                Else
                    If csentry("PreferredName").IsPresent And csentry("Surname").IsPresent Then
                        mventry("displayName").Value = csentry("Surname").Value + ", " + csentry("PreferredName").Value + " (" + Initials + ")"
                    Else
                        mventry("displayName").Value = csentry("Surname").Value + ", " + csentry("Firstname").Value + " (" + Initials + ")"
                    End If
                End If

                    'Case "IAFdisplayName"
                    '             ' The following format is used Firstname/preferredName, surname (initials)
                    '             Dim Initials As String = Nothing

                    '             ' !!! need to create a secondname field in the SQL database then enable code below !!

                    '             If csentry("preferredName").IsPresent And _
                    '                csentry("firstName").IsPresent And _
                    '                csentry("secondName").IsPresent And _
                    '                csentry("surname").IsPresent Then
                    '                 Initials = csentry("firstName").StringValue.Substring(0, 1) + csentry("secondName").StringValue.Substring(0, 1)
                    '                 mventry("displayName").Value = csentry("preferredName").Value + " " + csentry("surname").Value + " (" + Initials + ")"
                    '             ElseIf csentry("preferredName").IsPresent And _
                    '                    csentry("firstName").IsPresent And _
                    '                     csentry("surname").IsPresent Then
                    '                 Initials = csentry("firstName").StringValue.Substring(0, 1)
                    '                 mventry("displayName").Value = csentry("preferredName").Value + " " + csentry("surname").Value + " (" + Initials + ")"
                    '             Else
                    '                 Initials = csentry("preferredName").StringValue.Substring(0, 1)
                    '                 mventry("displayName").Value = csentry("preferredName").Value + " " + csentry("surname").Value + " (" + Initials + ")"
                    '             End If

            Case "IAFuid"
                    If Not mventry("uid").IsPresent Then
                        Dim accountType As String = "P"
                        mventry("uid").Value = CustomUtils.Utilities.GenerateUID(csentry, accountType, PermanentPrefix).ToString
                    End If


            Case Else
                    ' TODO: remove the following statement and add your default script here
                    Throw New EntryPointNotImplementedException()

        End Select
    End Sub

    Public Sub MapAttributesForExport(ByVal FlowRuleName As String, ByVal mventry As MVEntry, ByVal csentry As CSEntry) Implements IMASynchronization.MapAttributesForExport
        ' TODO: Add export attribute flow code here
        Throw New EntryPointNotImplementedException()
    End Sub

    Public Function Deprovision(ByVal csentry As CSEntry) As DeprovisionAction Implements IMASynchronization.Deprovision
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function
End Class
