
Imports Microsoft.MetadirectoryServices
Imports CustomUtils.Utilities
Imports CustomUtils.Constants


Public Class MAExtensionObject
    Implements IMASynchronization

    Public Sub Initialize() Implements IMASynchronization.Initialize
        ' TODO: Add initialization code here
    End Sub

    Public Sub Terminate() Implements IMASynchronization.Terminate
        ' TODO: Add termination code here
    End Sub

    Public Function ShouldProjectToMV(ByVal csentry As CSEntry, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ShouldProjectToMV
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function

    Public Function FilterForDisconnection(ByVal csentry As CSEntry) As Boolean Implements IMASynchronization.FilterForDisconnection
        ' TODO: Add connector filter code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForJoin(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByRef values As ValueCollection) Implements IMASynchronization.MapAttributesForJoin
        ' TODO: Add join mapping code here
        Throw New EntryPointNotImplementedException()
    End Sub

    Public Function ResolveJoinSearch(ByVal joinCriteriaName As String, ByVal csentry As CSEntry, ByVal rgmventry() As MVEntry, ByRef imventry As Integer, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ResolveJoinSearch
        ' TODO: Add join resolution code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForImport(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByVal mventry As MVEntry) Implements IMASynchronization.MapAttributesForImport
        ' TODO: write your import attribute flow code
        Select Case FlowRuleName
            Case "IAFemployeeStatus"

                Dim currentValue As Long = 0
                Dim employeeStatus As String

                ' Check the availability of the employee in connectorspace and corresponding status in metaverse
                If mventry("employeeStatus").IsPresent And csentry("userAccountControl").IsPresent Then

                    currentValue = csentry("userAccountControl").IntegerValue

                    ' Test if UF_NORMAL_ACCOUNT and UD_DISABLEDACCOUNT are set
                    employeeStatus = mventry("employeeStatus").Value


                    If ( _
                        (employeeStatus = EMPLOYEE_ACTIVE) And _
                        ((currentValue = UF_NORMAL_ACCOUNT + UF_ACCOUNTDISABLE) Or _
                        (currentValue = UF_NORMAL_ACCOUNT + UF_ACCOUNTDISABLE + UF_DONT_EXPIRE_PASSWD) Or _
                        (currentValue = UF_NORMAL_ACCOUNT + UF_ACCOUNTDISABLE + UF_PASSWD_NOTREQD)) _
                         ) Then
                        '(currentValue And UF_NORMAL_ACCOUNT) = UF_NORMAL_ACCOUNT) And _
                        '                        ((currentValue And UF_ACCOUNTDISABLE) = UF_ACCOUNTDISABLE) _
                        '                        ) Then
                        ' This is an account which has just been disabled. Accept the change
                        mventry("employeeStatus").Value = EMPLOYEE_DISABLED
                    End If
                End If
        End Select
    End Sub

    Public Sub MapAttributesForExport(ByVal FlowRuleName As String, ByVal mventry As MVEntry, ByVal csentry As CSEntry) Implements IMASynchronization.MapAttributesForExport
        ' TODO: Add export attribute flow code here
        Throw New EntryPointNotImplementedException()
    End Sub

    Public Function Deprovision(ByVal csentry As CSEntry) As DeprovisionAction Implements IMASynchronization.Deprovision
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function
End Class
