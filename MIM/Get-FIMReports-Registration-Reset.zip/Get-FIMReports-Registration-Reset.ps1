﻿<#
FIM Reports
Inobits Script
2014/04/11
version 1.0

Description:
-Number of users that registered
-Number of users that used FIM to reset their own password
#>


#Set the FIM Service address
set-variable -name URI -value "http://localhost:5725/resourcemanagementservice' " -option constant

#Target output folder
$TARGETDIR = 'C:\Reports'

#Get todays date
$StartDate=(GET-DATE)

#The export csv files
set-variable -name PasswordResetUsers -value "PasswordResetUsers.csv" -option constant
set-variable -name PasswordResetUsers -value "NPasswordResetUsers.csv" -option constant
set-variable -name RegistredUsers -value "RegistredUsers.csv" -option constant
set-variable -name NotRegistredUsers -value "NotRegistredUsers.csv" -option constant
set-variable -name WithoutDisplayName -value "UsersWithoutDisplayName.csv" -option constant
set-variable -name WithoutManager -value "UsersWithoutManagers.csv" -option constant
set-variable -name secGroupWithoutOwner -value "SecutiryGroupWithoutOwner.csv" -option constant
set-variable -name DLGroupWithoutOwner -value "DistributionGroupWithoutOwner.csv" -option constant


clear

#Check if the FIMAutomation Snapin is loaded. If no load it
If(@(Get-PSSnapin | Where-Object {$_.Name -eq "FIMAutomation"} ).count -eq 0) {Add-PSSnapin FIMAutomation} 




#-----------Begin PasswordReset--------------------------
        #Set some FIM Service objects
        #AnonymousUser ObjectID 
        $AnonymousUser = "b0b36673-d43b-4cfa-a7a2-aff14fd90522"


        #Select the correct MPR--------------------------
        # Default MPR for Anonymous users can reset their passwords
        # $AnonUsersCanResetPasswordMPR = "505e53d9-0f5e-4156-a722-a71621e02281"
        $MPRFilter = "/ManagementPolicyRule[DisplayName='Anonymous users can reset their password']"
        $curObjectMPR = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($MPRFilter) -ErrorVariable Err -ErrorAction SilentlyContinue
        $AnonUsersCanResetPasswordMPR = (($curObjectMPR.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "ObjectID"}).value).split(":")[2]

        # Custom MPR for Anonymous users can reset their passwords
        # $AnonUsersCanResetPasswordMPR = "d322d607-b367-459e-8dc3-215471c8ecae"
        #$MPRFilter = "/ManagementPolicyRule[DisplayName='Password Reset: All Active Users Can Reset Password']"
        #$curObjectMPR = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($MPRFilter) -ErrorVariable Err -ErrorAction SilentlyContinue
        #$AnonUsersCanResetPasswordMPR = (($curObjectMPR.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "ObjectID"}).value).split(":")[2]

                
        
        #Set the XPATH Filter for PasswordReset----------
        $filterPasswordReset = "/Request[" + "Creator='$AnonymousUser' and " + "ManagementPolicy = '$AnonUsersCanResetPasswordMPR' and " + "RequestStatus = 'Completed'" + "]"
        #This filter does not include the MPR Anonymous users can reset their passwords
        #$filterPasswordReset = "/Request[" + "Creator='$AnonymousUser' and " + "RequestStatus = 'Completed'" + "]"

        #Get all the objects that match the filter for PasswordReset
        $curObjectPasswordReset = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($filterPasswordReset) -ErrorVariable Err -ErrorAction SilentlyContinue

        [array]$usersPasswordReset = $null

        foreach($Object in $curObjectPasswordReset) 
        {

         #Get the CommittedTime of the PasswordReset
         [DateTime]$CommittedTime = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "CommittedTime"}).Value)
         #Add +2Hours for localization
         $CommittedTime = $CommittedTime.AddHours(2)
  
             #If this CommittedTime is less than 30 days ago
             #if ((New-TimeSpan -Start $StartDate -End $CommittedTime).Days -ge -30)

             #If this CommittedTime is in the same month as the current month
             if ($CommittedTime.Month -eq $StartDate.Month)
                 {   
                 #Set the DisplayName Value
                 $UserDisplayName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "DisplayName"}).Value)
                 #Cleanup the DisplayName
                 $UserDisplayName = $UserDisplayName.Replace("Update to Person:","")
                 $UserDisplayName = $UserDisplayName.Replace("Request","")
                 $UserDisplayName = $UserDisplayName.Replace("'","")
                 $UserDisplayName = ($UserDisplayName).trim()

                 #Use the Target ObjectId to lookup the AccountName value
                 $Target = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "Target"}).Value)
                 #Cleanup the Target value
                 $Target = $Target.Replace("urn:uuid:","")
                 #Look up the AccountName
                 $FilterTarget = "/Person[ObjectID='$Target']"
                 $LookupPerson = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($FilterTarget) -ErrorVariable Err -ErrorAction SilentlyContinue
                 $UserAccountName = (($LookupPerson.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "AccountName"}).Value)

                 #Create new object
                 $ResetPass = New-Object PSObject
                 $ResetPass | Add-Member NoteProperty "DisplayName" $UserDisplayName
                 $ResetPass | Add-Member NoteProperty "CommittedTime" $CommittedTime
                 $ResetPass | Add-Member NoteProperty "AccountName" $UserAccountName
                 $ResetPass | Add-Member NoteProperty "Target" $Target
 
                 $UsersPasswordReset += $ResetPass
            }

     
        }

      #  $usersPasswordReset

#-----------End PasswordReset--------------------------



#-----------Begin PasswordRegister--------------------

        #Set the Workflows
        #Default Workflow for users that have completed the Questions for the Self-Service Password Reset workflow
        $WFDFilter = "/WorkflowDefinition[DisplayName='Password Reset AuthN Workflow']"
        #Custom Workflow for users that have completed the Questions for the Self-Service Password Reset workflow
        #$WFDFilter = "/WorkflowDefinition[DisplayName='Password Reset: All Active Users Authentication Configuration and Questions']"
        $curObjectWFD = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($WFDFilter) -ErrorVariable Err -ErrorAction SilentlyContinue 
        $WFDObjectID = (($curObjectWFD.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "ObjectID"}).value).split(":")[2]

        #Set the XPATH Filter for PasswordRegister and get the objects
        $FilterPasswordRegister = "/Person[AuthNWFRegistered = '$WFDObjectID']"
        $curObjectPasswordRegister = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($FilterPasswordRegister) -ErrorVariable Err -ErrorAction SilentlyContinue 


        [array]$usersPasswordRegister = $null 
        foreach($Object in $curObjectPasswordRegister) 
        {
         $RegPass = New-Object PSObject
         $UserDisplayName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "DisplayName"}).Value)
         $UserAccountName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "AccountName"}).Value)
         
         $RegPass | Add-Member NoteProperty "DisplayName" $UserDisplayName
         $RegPass | Add-Member NoteProperty "AccountName" $UserAccountName
         $UsersPasswordRegister += $RegPass
        }

        #$usersPasswordRegister
       
#-----------End PasswordRegister--------------------

<#
#-----------Begin Users that have not: PasswordRegister--------------------

        #Set the Workflows
        #Default Workflow for users that have completed the Questions for the Self-Service Password Reset workflow
        $WFDFilter = "/WorkflowDefinition[DisplayName='Password Reset AuthN Workflow']"
        #Custom Workflow for users that have completed the Questions for the Self-Service Password Reset workflow
        #$WFDFilter = "/WorkflowDefinition[DisplayName='Password Reset: All Active Users Authentication Configuration and Questions']"
        $curObjectWFD = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($WFDFilter) -ErrorVariable Err -ErrorAction SilentlyContinue 
        $WFDObjectID = (($curObjectWFD.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "ObjectID"}).value).split(":")[2]

        #Set the XPATH Filter for PasswordRegister and get the objects
        $FilterPasswordRegister = "/Person[not(AuthNWFRegistered = '$WFDObjectID')]"
        $curObjectPasswordRegister = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($FilterPasswordRegister) -ErrorVariable Err -ErrorAction SilentlyContinue 


        [array]$usersNotPasswordRegister = $null 
        foreach($Object in $curObjectPasswordRegister) 
        {
         $RegPass = New-Object PSObject
         $UserDisplayName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "DisplayName"}).Value)
         $UserAccountName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "AccountName"}).Value)
         
         $RegPass | Add-Member NoteProperty "DisplayName" $UserDisplayName
         $RegPass | Add-Member NoteProperty "AccountName" $UserAccountName
         $UsersNotPasswordRegister += $RegPass
        }

        #$usersPasswordRegister
       
#-----------End Users that have not: PasswordRegister--------------------




#-----------Begin All users without a DisplayName--------------------
         #All users without a DisplayName:
         $FilterTarget = "/Person[not(DisplayName != '&Invalid&')]"
         $LookupPersonWithoutDisplayName = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($FilterTarget) -ErrorVariable Err -ErrorAction SilentlyContinue

         [array]$usersWithoutDisplayName = $null 
            foreach($Object in $LookupPersonWithoutDisplayName) 
            {
             $WHDisplay = New-Object PSObject
             $UserAccountName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "AccountName"}).Value)
             $WHDisplay | Add-Member NoteProperty "AccountName" $UserAccountName
             $usersWithoutDisplayName += $WHDisplay
            }

       
      # $usersWithoutDisplayName
#-----------End All users without a DisplayName--------------------



#-----------Begin All users without a Manager--------------------
         #All users without a manager:
         $FilterTarget = "/Person[not(Manager=/Person)]"
         $LookupPersonWithoutManager = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($FilterTarget) -ErrorVariable Err -ErrorAction SilentlyContinue

         [array]$usersWithoutManager = $null 
            foreach($Object in $LookupPersonWithoutManager) 
            {
             $WMDisplay = New-Object PSObject
             $UserDisplayName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "DisplayName"}).Value)
             $UserAccountName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "AccountName"}).Value)
             $WMDisplay | Add-Member NoteProperty "DisplayName" $UserDisplayName
             $WMDisplay | Add-Member NoteProperty "AccountName" $UserAccountName
             
             $usersWithoutManager += $WMDisplay
            }

       
      #$usersWithoutManager

#-----------End All users without a Manager--------------------




#-----------Begin All security groups without an owner-----------------

           $FilterTarget = "/Group[Type='Security' and not(Owner=/Person)]"
           $LookupGroup = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($FilterTarget) -ErrorVariable Err -ErrorAction SilentlyContinue

            [array]$secGroupWithoutOwner = $null 
            foreach($Object in $LookupGroup) 
            {
             $secDisplay = New-Object PSObject
             $secDisplayName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "DisplayName"}).Value)
             $secDisplay | Add-Member NoteProperty "DisplayName" $secDisplayName
             $secGroupWithoutOwner += $secDisplay
            }

           # $secGroupWithoutOwner
#-----------End All security groups without an owner----------------




 #----------Begin All distribution groups without a Owner------------

             $FilterTarget = "/Group[Type='Distribution' and not(Owner=/Person)]"
             $LookupGroup = export-fimconfig -uri $URI –onlyBaseResources -customconfig ($FilterTarget) -ErrorVariable Err -ErrorAction SilentlyContinue

              [array]$dlGroupWithoutOwner = $null 
            foreach($Object in $LookupGroup) 
            {
             $dlDisplay = New-Object PSObject
             $dlDisplayName = (($Object.ResourceManagementObject.ResourceManagementAttributes | Where-Object {$_.AttributeName -eq "DisplayName"}).Value)
             $dlDisplay | Add-Member NoteProperty "DisplayName" $dlDisplayName
             $dlGroupWithoutOwner += $dlDisplay
            }

           # $dlGroupWithoutOwner

           
  #----------End All distribution groups without a Owner-------------

#>




#Check if the Target Folder expires and create if needed.
if(!(Test-Path -Path $TARGETDIR))
{
    New-Item -ItemType directory -Path $TARGETDIR
}

#Export the results into a csv file
$usersPasswordRegister | export-csv -path $TARGETDIR\$RegistredUsers
#$UsersNotPasswordRegister | export-csv -Path $TARGETDIR\$NotRegistredUsers
$usersPasswordReset | export-csv -Path $TARGETDIR\$PasswordResetUsers
#$usersWithoutDisplayName | export-csv -Path $TARGETDIR\$WithoutDisplayName
#$usersWithoutManager| export-csv -Path $TARGETDIR\$WithoutManager
#$secGroupWithoutOwner | export-csv -Path $TARGETDIR\$secGroupWithoutOwner
#$dlGroupWithoutOwner | export-csv -Path $TARGETDIR\$DLGroupWithoutOwner

