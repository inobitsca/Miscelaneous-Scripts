﻿Set-Alias -Name Project-CSObject -Value New-MVObject
Export-ModuleMember -Alias *