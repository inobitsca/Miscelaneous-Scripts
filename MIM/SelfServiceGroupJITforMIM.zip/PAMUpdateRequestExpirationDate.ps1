param($arg1)
$TargetID=$arg1
#$TargetID="375ede3c-8cde-4eb2-95f0-f54eedcdad42"

#Load the Lithnet FIM PowerShell Module
Import-Module LithnetRMA

#Load ActiveDirectory PowerShell Modules
Import-Module ActiveDirectory

#Get the PAM Group info
$PAMRequestInfo = Get-Resource -ObjectType msidmPamRequest -AttributeName ObjectID -AttributeValue $TargetID
[DateTime]$RequestExpirationDate= $PAMRequestInfo.msidmPamRequestExpirationDate

#Update the New Expiration Date
$NewRequestExpirationDate=$RequestExpirationDate.AddSeconds($PAMRequestInfo.PamRequestExtension)
$PAMRequestInfo.msidmPamRequestExpirationDate=$NewRequestExpirationDate

#Clear request expiration
$PAMRequestInfo.PamRequestExtension = $null

#Save the updated object
save-resource $PAMRequestInfo


