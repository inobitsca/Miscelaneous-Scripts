param($arg1)
$TargetID=$arg1
#$TargetID="b71582f7-054a-4da5-9411-1201dbe85a31"

#Load the Lithnet FIM PowerShell Module
Import-Module LithnetRMA

#Load ActiveDirectory PowerShell Modules
Import-Module ActiveDirectory

#Get the PAM Group info
$PAMGroupInfo = Get-Resource -ObjectType PAMGroups -AttributeName ObjectID -AttributeValue $TargetID
$NewPAMGroupName= $PAMGroupInfo.DisplayName + "_PAM"

#Does the SG Exist
$ProcessPAMG=Get-ADgroup $PAMGroupInfo.DisplayName

#If it exisit then proceed
If ($ProcessPAMG -ne $null){

#Create the PAMGroups of the SG
New-ADGroup -Name $NewPAMGroupName -SamAccountName $NewPAMGroupName -GroupCategory Security -GroupScope Global -DisplayName $NewPAMGroupName -Path "OU=PAM objects,DC=TLKEnterprise,DC=net" -ManagedBy tlkfimportalserv  

#Add the PAM Group created as member of SG to be monitored
Add-ADGroupMember $PAMGroupInfo.DisplayName $NewPAMGroupName

#Create the PAM Group
New-PAMGroup -SourceDomain tlkenterprise.net -SourceGroupName $NewPAMGroupName �PrivOnly
}
