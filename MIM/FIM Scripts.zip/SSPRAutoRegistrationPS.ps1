Add-PSSnapin FIMAutomation
Import-Module c:\scripts\FimPowerShellModule.psm1
Import-module Activedirectory

$users = Get-ADUser -SearchBase "OU=mim,DC=inobitsza,dc=com" -Properties emailaddress ,extensionAttribute1 -Filter 'extensionAttribute1 -notlike "*" -And emailaddress -like "*"' 
#$users
foreach ($user in $users)
 {

$Email = $user.EmailAddress
$un = "Inobitsza\" + $user.Samaccountname

#$un 
#$user.EmailAddress 


if($Email)
 {
  $template = Get-AuthenticationWorkflowRegistrationTemplate -AuthenticationWorkflowName 'Password Reset AuthN Workflow'
  #$template
  $template.GateRegistrationTemplates[0].Data[0].Value = $Email
  $result  = Register-AuthenticationWorkflow -UserName $UN -AuthenticationWorkflowRegistrationTemplate $template

  #Write-host "The result for" $user.SAMACCOUNTNAME
  	if ($result -eq "Registration Successful") 
		{
  		Set-ADUser $user.samaccountname -Add @{extensionAttribute1="Registered"}
 		}
	}
}